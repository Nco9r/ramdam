<template>
  <section class="navbar">
    <div class="box_navbar">
      <div class="box_item_navbar">
        <nuxt-link to="/"
          ><div class="box_svg">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="17.979"
              height="20"
              viewBox="0 0 17.979 20"
            >
              <path
                id="estate_2_"
                data-name="estate (2)"
                d="M19.98,7.993h0L13.987,2.739a3,3,0,0,0-4,0L4,7.993A3,3,0,0,0,3,10.25v8.73a3,3,0,0,0,3,3H17.982a3,3,0,0,0,3-3V10.24A3,3,0,0,0,19.98,7.993ZM13.987,19.978h-4V14.984a1,1,0,0,1,1-1h2a1,1,0,0,1,1,1Zm4.994-1a1,1,0,0,1-1,1h-2V14.984a3,3,0,0,0-3-3h-2a3,3,0,0,0-3,3v4.994H6a1,1,0,0,1-1-1V10.24a1,1,0,0,1,.34-.749L11.33,4.247a1,1,0,0,1,1.318,0l5.993,5.244a1,1,0,0,1,.34.749Z"
                transform="translate(-3 -1.976)"
                fill="#a0a0a0"
              />
            </svg>
          </div>

          <p>Bsdasris</p>
        </nuxt-link>
      </div>
      <div class="box_item_navbar">
        <nuxt-link to="/transport/to-collect">
          <div class="box_svg">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="19.989"
              height="17.263"
              viewBox="0 0 19.989 17.263"
            >
              <path
                id="truck"
                d="M1,11.586v4.543a.909.909,0,0,0,.909.909h.909a2.726,2.726,0,1,0,5.452,0H13.72a2.726,2.726,0,1,0,5.452,0h.909a.909.909,0,0,0,.909-.909V5.226A2.726,2.726,0,0,0,18.263,2.5H10.086A2.726,2.726,0,0,0,7.36,5.226V7.043H5.543a2.726,2.726,0,0,0-2.181,1.09L1.182,11.041a.554.554,0,0,0-.064.127l-.055.1A.909.909,0,0,0,1,11.586Zm14.538,5.452a.909.909,0,1,1,.909.909A.909.909,0,0,1,15.538,17.038ZM9.177,5.226a.909.909,0,0,1,.909-.909h8.177a.909.909,0,0,1,.909.909V15.22h-.709a2.726,2.726,0,0,0-4.034,0H9.177ZM7.36,10.677H3.726l1.09-1.454a.909.909,0,0,1,.727-.363H7.36Zm-2.726,6.36a.909.909,0,1,1,.909.909A.909.909,0,0,1,4.634,17.038ZM2.817,12.495H7.36v2.526a2.726,2.726,0,0,0-3.834.2H2.817Z"
                transform="translate(-1 -2.5)"
                fill="#a0a0a0"
              />
            </svg>
          </div>

          <p>Route</p>
        </nuxt-link>
      </div>

    <nuxt-link to="/choose-events"><p class="create">+</p> </nuxt-link>

      <div class="box_item_navbar">
        <nuxt-link to="/fiche-clients"
          ><div class="box_svg">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="18.172"
              height="17.263"
              viewBox="0 0 18.172 17.263"
            >
              <path
                id="folder_1_"
                data-name="folder (1)"
                d="M17.446,5.226H11.74l-.291-.909A2.726,2.726,0,0,0,8.869,2.5H4.726A2.726,2.726,0,0,0,2,5.226V17.038a2.726,2.726,0,0,0,2.726,2.726h12.72a2.726,2.726,0,0,0,2.726-2.726V7.952A2.726,2.726,0,0,0,17.446,5.226Zm.909,11.812a.909.909,0,0,1-.909.909H4.726a.909.909,0,0,1-.909-.909V5.226a.909.909,0,0,1,.909-.909H8.869a.909.909,0,0,1,.863.618l.491,1.49a.909.909,0,0,0,.863.618h6.36a.909.909,0,0,1,.909.909Z"
                transform="translate(-2 -2.5)"
                fill="#a0a0a0"
              />
            </svg>
          </div>

          <p>Clients</p>
        </nuxt-link>
      </div>
      <div class="box_item_navbar">
        <nuxt-link to="/reglages"
          ><div class="box_svg">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="18.814"
              height="19.152"
              viewBox="0 0 18.814 19.152"
            >
              <path
                id="setting_2_"
                data-name="setting (2)"
                d="M19.133,12.207a.957.957,0,0,1,0-1.264l1.226-1.379a.957.957,0,0,0,.115-1.12L18.558,5.131a.957.957,0,0,0-1.025-.46l-1.8.364a.957.957,0,0,1-1.1-.632l-.584-1.752A.957.957,0,0,0,13.139,2H9.309a.957.957,0,0,0-.957.651L7.815,4.4a.957.957,0,0,1-1.1.632L4.866,4.671a.957.957,0,0,0-.957.46L1.994,8.444a.957.957,0,0,0,.1,1.12l1.216,1.379a.957.957,0,0,1,0,1.264L2.09,13.586a.957.957,0,0,0-.1,1.12l1.915,3.313a.957.957,0,0,0,1.025.46l1.8-.364a.957.957,0,0,1,1.1.632L8.419,20.5a.957.957,0,0,0,.957.651h3.83a.957.957,0,0,0,.91-.651l.584-1.752a.957.957,0,0,1,1.1-.632l1.8.364a.957.957,0,0,0,1.025-.46l1.915-3.313a.957.957,0,0,0-.115-1.12ZM17.706,13.49l.766.862-1.226,2.126-1.13-.23a2.872,2.872,0,0,0-3.3,1.915l-.364,1.072H10l-.345-1.092a2.872,2.872,0,0,0-3.3-1.915l-1.13.23L3.976,14.342l.766-.862a2.872,2.872,0,0,0,0-3.83l-.766-.862L5.2,6.682l1.13.23A2.872,2.872,0,0,0,9.635,5L10,3.915H12.45l.364,1.092a2.872,2.872,0,0,0,3.3,1.915l1.13-.23,1.226,2.126-.766.862a2.872,2.872,0,0,0,0,3.811ZM11.224,7.745a3.83,3.83,0,1,0,3.83,3.83A3.83,3.83,0,0,0,11.224,7.745Zm0,5.745a1.915,1.915,0,1,1,1.915-1.915A1.915,1.915,0,0,1,11.224,13.49Z"
                transform="translate(-1.857 -1.999)"
                fill="#a0a0a0"
              />
            </svg>
          </div>

          <p>Réglages</p>
        </nuxt-link>
        
      </div>
        
    </div>
  </section>
</template>

<script>
export default {}
</script>

<style scoped>
.nuxt-link-exact-active path {
  fill: var(--green) !important;
}

.nuxt-link-exact-active p {
  color: var(--green) !important;
  font-weight: 700;
}
.navbar {
  position: fixed;
  left: 0;
  bottom: 0;
  right: 0;
  z-index: 1;
  border-top: 1px solid var(--gray-step);
  height: 100px;
  z-index: 9;
  background-color: var(--white);
}

.box_navbar {
  padding: 0 30px;
  display: flex;
  flex-flow: row;
  margin-top: 25px;
  justify-content: space-between;
  align-items: center;
}

.box_item_navbar a {
  display: flex;
  flex-flow: column;
  align-items: center;
  justify-items: center;
}

.box_svg {
  height: 20px;
}

.box_item_navbar a p {
  color: var(--gray-nav);
  font-size: 12px;
  font-weight: 700;
  margin-top: 2px;
}

a {
  text-decoration: none;
}

.create {
  height: 45px;
  width: 45px;
  border-radius: 10px;
  color: var(--black);
  background-color: var(--yellow);
  display: flex;
  margin-top: -5px;
  justify-content: center;
  align-items: center;
  font-size: 18px;
  font-weight: 700;
}

path {
  fill: var(--gray-nav);
}

a .sous_item {
  height: 0px;
  width: 0px;
  border-radius: 50%;
  color: var(--gray-step);
  background-color: transparent;
  display: flex;
  margin-top: -5px;
  justify-content: center;
  align-items: center;
  font-size: 18px;
  font-weight: 700;
}
</style>
